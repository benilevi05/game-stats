import {
  Avatar,
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Divider,
  IconButton,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import React from "react";
import TwitterIcon from "@mui/icons-material/Twitter";
import InstagramIcon from "@mui/icons-material/Instagram";
import FacebookIcon from "@mui/icons-material/Facebook";
import LanguageIcon from "@mui/icons-material/Language";
import LinkedInIcon from "@mui/icons-material/LinkedIn";

interface Props {
  companyName: string;
  companyLink: string;
  imageSource: string;
  twitterUrl: string;
  instagramUrl: string;
  facebookUrl: string;
  linkedinUrl: string;
}

const CompanyCard = ({
  companyName,
  companyLink,
  imageSource,
  twitterUrl,
  instagramUrl,
  facebookUrl,
  linkedinUrl,
}: Props) => {
  return (
    <Paper elevation={2}>
      <Box
        sx={{
          objectPosition: "50% 50%",
          p: "20px",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <CardMedia
          component="img"
          image={imageSource}
          alt="company logo"
          sx={{
            objectFit: "scale-down",
            border: "dotted 1px",
            borderColor: "lightblue",
            borderRadius: "10px",
            height: 90,
            width: 90,
            marginLeft: "auto",
            marginRight: "auto",
            padding: "2px",
          }}
        />
      </Box>

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
        }}
      >
        <CardContent sx={{ marginTop: -3 }}>
          <Typography
            variant="h5"
            component="div"
            sx={{ fontFamily: "Rockwell" }}
          >
            {companyName}
          </Typography>
        </CardContent>
        <CardActions sx={{ marginTop: -2, gap: 0.2 }}>
          {companyLink ? (
            <IconButton size="small" href={companyLink} sx={{ color: "" }}>
              <LanguageIcon />
            </IconButton>
          ) : null}
          {linkedinUrl ? (
            <IconButton
              size="small"
              href={linkedinUrl}
              sx={{ color: "#0072b1" }}
            >
              <LinkedInIcon />
            </IconButton>
          ) : null}
          {twitterUrl ? (
            <IconButton
              size="small"
              href={twitterUrl}
              sx={{ color: "#1DA1F2" }}
            >
              <TwitterIcon />
            </IconButton>
          ) : null}
          {instagramUrl ? (
            <IconButton
              size="small"
              href={instagramUrl}
              sx={{ color: " #e95950" }}
            >
              <InstagramIcon />
            </IconButton>
          ) : null}
          {facebookUrl ? (
            <IconButton
              size="small"
              href={facebookUrl}
              sx={{ color: "#4267B2" }}
            >
              <FacebookIcon />
            </IconButton>
          ) : null}
        </CardActions>
      </Box>
    </Paper>
  );
};

export default CompanyCard;
