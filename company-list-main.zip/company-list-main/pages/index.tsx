import type { NextPage } from "next";
import CompanyCard from "../src/components/CompanyCard";
import CompanyData from "../src/components/company-data.json";
import { Box, Grid, Stack } from "@mui/material";

const Home: NextPage = () => {
  return (
    <Box p={4}>
      <Grid container spacing={4}>
        {CompanyData &&
          CompanyData.map((company) => {
            return (
              <Grid item xs={12} sm={6} md={4} lg={2}>
                <CompanyCard
                  key={company.id}
                  companyName={company.name}
                  companyLink={company.siteLink}
                  imageSource={company.logo}
                  twitterUrl={company.twitterLink}
                  instagramUrl={company.instagramLink}
                  facebookUrl={company.facebookLink}
                  linkedinUrl={company.linkedinLink}
                />
              </Grid>
            );
          })}
      </Grid>
    </Box>
  );
};

export default Home;
